require "mixlib/log"

module ChefZero
  class Log
    extend Mixlib::Log
  end
end
