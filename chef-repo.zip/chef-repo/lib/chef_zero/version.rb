module ChefZero
  VERSION = "5.1.0"
end
